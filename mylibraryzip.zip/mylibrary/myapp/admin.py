from django.contrib import admin
from .models import Author, Book, BorrowRecord, User

# Register your models here.
admin.site.register(Book) 
admin.site.register(Author) 
admin.site.register(BorrowRecord) 
admin.site.register(User)
