

# Create your models here.
from datetime import datetime
# from typing import AbstractSet
from django.db import models

# from .models import User

   
    
class Author(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    bio = models.TextField() 
    def __str__(self):
        return self.name   
    
class Book(models.Model):
    title = models.CharField(max_length=50) 
    author = models.ForeignKey(Author, on_delete=models.CASCADE)   
    genre = models.TextField( null=True, blank=True)
    published_date = models.DateField(null=True, blank=True)
    AVAILABILITY_CHOICES = (
        ('Available', 'Available'),
        ('Borrowed', 'Borrowed'),
  
    )

    availability_status = models.CharField(
        max_length=10,
        choices=AVAILABILITY_CHOICES,
        default='available',  # You can set the default status as 'available'
    )
    
    def __str__(self):
        return self.title
    
class User(models.Model):
    name = models.CharField(max_length=50)
    number = models.IntegerField(null=True)
    adress = models.TextField()
    def __str__(self):
        return self.name     
    
class BorrowRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    borrow = models.DateField(auto_now=True) 
    returns = models.DateField(auto_now=True) 

    def is_return(self):
        self.borrow = datetime.now()
        self.returns = True
        self.save()
        

        
        