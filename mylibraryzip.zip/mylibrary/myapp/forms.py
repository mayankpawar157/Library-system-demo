from django import forms
from .models import Author, Book, BorrowRecord, User




        
class AuthorForm(forms.ModelForm):
    class Meta:
        model = Author
        fields = '__all__'
        
class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'
        
class BorrowRecordForm(forms.ModelForm):
    class Meta:
        model = BorrowRecord
        fields = '__all__'
        
class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = '__all__'        