from pyexpat.errors import messages
from django.shortcuts import render, redirect, get_object_or_404

from .models import User

from .forms import AuthorForm, BookForm
from .models import Author, Book, BorrowRecord


def home(request):
    return render(request, 'home.html')

def book_list(request):
    data = Book.objects.all()
    return render(request, 'book_list.html', {"data":data})

def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request, 'add_book.html', {'form': form})



def add_author(request):
    if request.method == 'POST':
        form = AuthorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('author_list')
    else:
        form = AuthorForm()
    return render(request, 'add_author.html', {'form': form})

def author_list(request):
    data = Author.objects.all()
    return render(request, 'author_list.html',{"data":data} )

def borrow_book(request, id):
    book = Book.objects.get(id=id)
    if book.availability_status == 'Available':
        book.availability_status = 'Borrowed'
        book.save()
        list = BorrowRecord(user = request.user, book = book)
        list.save()
        return redirect(borrow_success)
    else:
        return redirect(borrow_failure)

    
    return render(request, 'home.html', {"book":book})
    
# def borrow_book(request, id):
#     book = Book.objects.get(id=id)
#     return redirect('borrow_success')    

def borrow_success(request):
    return render(request, 'borrow_successful.html')


def borrow_failure(request):
    return render(request, 'borrow_failure.html')

# def borrow_history(request):
#     return render(request, 'borrow_history.html' )

def return_book(request, id):
    entry = get_object_or_404(BorrowRecord, id=id)
    if entry.returns:
        return render(request, 'return_book.html')
    
    else:
        borrowed_book = entry.book
        borrowed_book.availability_status = 'Available'
        borrowed_book.save()

        entry.returns = True
        entry.save()

        return redirect('borrow_success')
    
def user(request,id):
    data = User.objects.get(id=id)
    return render(request, 'user.html', {"data":data})

def borrow_history(request):
    data = BorrowRecord.objects.all()
    return render(request, 'history.html', {"data":data})
        




        


