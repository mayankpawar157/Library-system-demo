
from django.urls import path
from .views import add_author, add_book, author_list, book_list, borrow_book, borrow_failure, borrow_history, borrow_success, home, return_book, user

urlpatterns = [
    path('',home, name='home'),
    path('book_list/', book_list, name='book_list'),
    path('add_book',add_book, name='add_book'),
    path('author_list/', author_list, name='author_list'),
    path('add_author',add_author, name='add_author'),
    path('borrow_history/', borrow_history, name='borrow_history'),
    path('borrow_book/<int:id>/', borrow_book, name='borrow_book'),
    path('borrow_success/', borrow_success, name='borrow_success'),
    path('borrow_failure/', borrow_failure, name='borrow_failure'),
    path('return_book/<int:id>/', return_book, name='return_book'),
    path('user/<int:id>/',user, name='user')
    
]